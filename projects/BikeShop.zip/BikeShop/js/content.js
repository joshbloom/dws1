/*
 * Use AJAX to load the JSON and manipulate the HTML
 * https://josbloom.github.io/dws1/data/bikeshop.json
*/